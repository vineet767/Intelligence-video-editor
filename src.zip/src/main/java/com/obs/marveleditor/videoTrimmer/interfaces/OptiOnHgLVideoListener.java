

package com.obs.marveleditor.videoTrimmer.interfaces;

public interface OptiOnHgLVideoListener {
    void onVideoPrepared();
}
