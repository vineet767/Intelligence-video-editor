

package com.obs.marveleditor.videoTrimmer.interfaces;

public interface OptiOnProgressVideoListener {
    void updateProgress(int time, int max, float scale);
}
