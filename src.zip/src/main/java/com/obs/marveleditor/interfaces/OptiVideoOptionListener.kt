

package com.obs.marveleditor.interfaces

interface OptiVideoOptionListener {
    fun videoOption(option: String)
}