

package com.obs.marveleditor.interfaces

interface OptiFilterListener {
    fun selectedFilter(filter: String)
}