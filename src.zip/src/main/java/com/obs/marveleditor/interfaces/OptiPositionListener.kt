

package com.obs.marveleditor.interfaces

interface OptiPositionListener {
    fun selectedPosition(position: String)
}