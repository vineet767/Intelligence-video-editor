

package com.obs.marveleditor.interfaces

interface OptiClipArtListener {
    fun selectedClipArt(path: String)
}