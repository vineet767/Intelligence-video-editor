

package com.obs.marveleditor.interfaces

interface OptiPlaybackSpeedListener {
    fun processVideo(playbackSpeed: String, tempo: String)
}