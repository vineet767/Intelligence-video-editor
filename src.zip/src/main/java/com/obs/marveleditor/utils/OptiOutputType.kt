

package com.obs.marveleditor.utils

class OptiOutputType {
    companion object {
        var TYPE_VIDEO = "video"
    }
}